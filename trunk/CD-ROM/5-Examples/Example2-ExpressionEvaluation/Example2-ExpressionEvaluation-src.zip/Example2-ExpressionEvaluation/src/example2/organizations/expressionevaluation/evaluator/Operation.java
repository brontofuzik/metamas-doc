package example2.organizations.expressionevaluation.evaluator;

/**
 * An operation.
 * @author Luk� K�dela
 * @since 2012-03-16
 * @version %I% %G%
 */
public enum Operation {
    NONE,
    ADDITION,
    SUBTRACTION,
    MULTIPLICATION,
    DIVISION
}
